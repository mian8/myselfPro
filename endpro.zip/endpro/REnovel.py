#coding=utf8

import requests,lxml,re,subprocess,pymysql,requests_html
from bs4 import BeautifulSoup
from dbutils.pooled_db import PooledDB
from zhconv import convert
from threading import Thread
from queue import Queue
import logging
import warnings
import time,datetime,json
import random,time
from selenium import webdriver
from myLibrary import getTime

logging.basicConfig(level=logging.INFO)

#传入ip和书籍，输出书籍所有的章节
class mianStream(object):
    def __init__(self,ip,bookname):
        pass

    #获取书籍章节列表
    def getBoooksindex(self):
        pass

    #获取可用ips
    def getIplist(self):
        pass

    #通过多线程获取数据每章对应页面
    #初始ip从指定章开始获取
    #获取失败，根据异常类型更换ip或者按照其他方式处理
    def getHtmlFromBookname(self,ipsList=[]):
        startip,name="",""
        num_threads = 3
        q = Queue()
        for i in range(num_threads):
            t = Thread(target=self.check_ip, args=(i, q))  # 批量创建线程
            t.setDaemon(True)  # 设置为守护线程  主线程A中，创建了子线程B，将A设置为守护线程，此时主线程A执行结束啦，不管子线程B是否执行完成，一并和A一起退出
            t.start()
        for i in ipsList:
            q.put(i)

        print("main thread waiting ...")
        q.join()  # 主线程A中，创建了子线程B，并在主线程中设置B.join(),那么，主线程A会在调用的地方等待，直到子线程B完成操作后，才可以继续向下执行。
        print("Done")

    #将获取的页面直接存到数据库，等待处理
    def savevovel(self):
        pass

#获取ip的类
class getIpAndCheck(object):
    def __init__(self):
        self.headers={'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Encoding': 'gzip, deflate, sdch', 'Accept-Language': 'zh-CN,zh;q=0.8',
                   'Cache-Control': 'max-age=0', 'Connection': 'keep-alive',
                   'Cookie': '_free_proxy_session=BAh7B0kiD3Nlc3Npb25faWQGOgZFVEkiJTRhMTU0ZWM5ODJiYzJlYjQ4NDExN2Y5ODE3YTQ0NTJhBjsAVEkiEF9jc3JmX3Rva2VuBjsARkkiMW9mQWp0dDZkUk5LdFZCUFBUVDRpdHJJNklQU0JvT3N2V0ZYQ1RGd3ZETUk9BjsARg%3D%3D--621bafde391b32c3c994463d8809cb9c91c09ebf; Hm_lvt_0cf76c77469e965d2957f0553e6ecf59=1530606053,1530606061,1530606065,1530607108; Hm_lpvt_0cf76c77469e965d2957f0553e6ecf59=1530607108',
                   'Host': 'www.xicidaili.com', 'If-None-Match': 'W/"a5db219236a51312e5a622f1537ee0fa"',
                   'Upgrade-Insecure-Requests': '1',
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.221 Safari/537.36 SE 2.X MetaSr 1.0'}
        self.proxies = ""
        self.ips = []
        self.sqlDB=sqlDeal()

    #爬取A网址ip，通过指定方式A解析页面数据
    def getAndlxml(self,url,func):
        logging.info("开始爬取ip")
        ipDict = func(url) #通过指定方法解析出ip列表

        validIp= self.checkIp(ipDict) #验证获取有效ip
        end = self.sqlAndSave(validIp) #存储可用ip到数据库
        logging.warning(validIp)
        if end :
            logging.warning(f"**********\n本次获取到可用ip共{end}条\n**********")
        return ipDict

    #页面解析方法A
    def funcA(self,url):
        headers=self.headers
        proxies=self.proxies
        if proxies:
            response = requests.get(url, headers=headers, proxies=proxies)
        else:
            response = requests.get(url, headers=headers)
        logging.info("解析页面")
        html = BeautifulSoup(response.text, "lxml")
        # print(html)
        logging.debug(html)
        body = html.find("table", {"class": "table table-bordered table-striped"})
        ipDict = {}
        if body is None:logging.warning("没有定位到目标位置")
        else:
            tdLines = body.find_all("tr")
            for line in tdLines[1:]:
                # print(line)
                thValues = line.find_all("td")
                ip = thValues[0].get_text()
                port = thValues[1].get_text()
                ipDict[ip]=port
            # print(ipList)
        if ipDict== {} :
            logging.warning("目标页面没有获取到ip")
        logging.info(f"初始ip列表{ipDict}")
        return ipDict

    #页面解析方法B
    def funcB(self,url):
        driver = webdriver.Firefox()
        driver.get(url)
        htmlpage=driver.page_source
        driver.close()
        logging.info("解析页面")
        html = BeautifulSoup(htmlpage, "lxml")
        # print(html)
        logging.debug(html)
        body = html.find("table", {"class": "table table-hover"})
        ipDict = {}
        if body is None:
            logging.warning("没有定位到目标位置")
        else:
            tdLines = body.find_all("tr")
            for line in tdLines[1:]:
                # print(line)
                thValues = line.find_all("td")
                ipPort = thValues[0].get_text()
                ip, port =ipPort.split(":")
                ipDict[ip] = port
            # print(ipList)
        if ipDict == {}:
            logging.warning("目标页面没有获取到ip")
        logging.info(f"初始ip列表{ipDict}")
        return ipDict

    #页面解析方法C
    def funcC(self,url):
        """
        :param url:https://checkerproxy.net/api/archive/2020-11-25
        :return: {ip:port}
        """
        url=url+getTime(types="d")
        text=requests.get(url).text
        IpJson=json.loads(text)
        ipDict = {}
        for line in IpJson:
            if (line["type"] == 1 or line["type"] == 2) and line["kind"] != 0:
                ip, port = line["addr"].split(":")
                ipDict[ip] = port
        logging.info(f"ip爬取成功,共计{len(ipDict)}条")
        logging.debug(f"初始ip列表{ipDict}")
        return ipDict

    #剔除无用ip
    def checkIp(self,ipList):

        logging.info("检查IP是否有响应")
        #设置线程总数
        num_threads = 3
        q = Queue()
        #批量创建线程
        for i in range(num_threads):
            t = Thread(target=self._checkIPThread, args=(i, q))  # 批量创建线程
            t.setDaemon(True)  # 设置为守护线程  主线程A中，创建了子线程B，将A设置为守护线程，此时主线程A执行结束啦，不管子线程B是否执行完成，一并和A一起退出
            t.start()
        #循环推送变量至线程
        for i in ipList.items():
            q.put(i)
        print("主线程等待中 ...")
        q.join()  # 主线程A中，创建了子线程B，并在主线程中设置B.join(),那么，主线程A会在调用的地方等待，直到子线程B完成操作后，才可以继续向下执行。


        logging.debug(self.ips)
        logging.info("本次获取ip验证完毕")
        return self.ips

    # 通过ping验证ip是否有效
    def _checkIPThread(self,i,ipQueue):
        while True :
            #获取队列中一个待测试ip
            waiteChickIp=ipQueue.get()
            logging.debug(f"线程{i}正在开始验证:{waiteChickIp}")
            newIpLine={}
            #如果是包含端口的i字符串，则取前段
            newIpLine["ipAdress"] = ip = waiteChickIp[0]
            newIpLine["port"] = waiteChickIp[1]
            logging.debug("Thread {} pinging {}".format(i, ip))
            #内部验重，如果该ip出现在数据库，则直接舍弃验证
            if not self.sqlDB.duplicationIP(ip):
                #对ip进行ping，获取返回内容
                cmd_input = subprocess.Popen(["ping.exe", ip], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                             stderr=subprocess.PIPE, shell=True)
                cmd_out = cmd_input.stdout.read()
                #通过正则获取字段，判断ping结果是否符合要求
                regex = re.compile("\d+%", re.IGNORECASE)
                logging.debug(cmd_out.decode("gbk"))
                logging.debug("Thread {} end. {}".format(i, ip))
                wastePercentage=regex.findall(cmd_out.decode("gbk"))
                if wastePercentage == ["0%"] and b"ms" in cmd_out :
                    newIpLine["status"]=1
                    logging.debug("{}可用".format(ip))
                else:
                    logging.debug(f"丢失率{wastePercentage}%")
                    newIpLine["status"] = 0
                logging.debug(newIpLine)
                self.ips.append(newIpLine)
            else:newIpLine["status"]=0

            #队列为空时，结束线程
            if ipQueue.empty:
                ipQueue.task_done()
        return

    #组合sql，存储ip，清空ips
    def sqlAndSave(self,argv):
        logging.info("存储本次获取的ip")
        # self.sqlDB.saveIp(argv)
        end=self.sqlDB.saveIpList(argv)
        return end

#通过源获取小说
class getBooknameFromSourse(object):
    def __init__(self):
        self.baseUrl="https://www.dingdiann.com"
        self.session=requests_html.HTMLSession()
        pass

    def getToSearch(self,key):
        url=self.baseUrl+ "/searchbook.php"
        params={"keyword":f"{key}"}
        response = self.session.get(url,params=params)
        print(response.url)
        html=BeautifulSoup(response.text)
        step1 = html.find("div",{"class":"novelslist2"})
        results=step1.find_all("li")[1:]
        #没有找到小说
        if len(results)==0:return False
        novels=[]
        for line in results:
            new=[]
            print(line.get_text())
            for num in range(1,8):
                step = line.find("span", {"class": f"s{num}"})
                text = self.getText(step)
                new.append(text)
                if num == 2:
                    link = step.a.get("href")
                    new.append(link)
                elif num==3:
                    link = step.a.get("href")
                    new.append(link)
            novels.append(new)
        print(novels)
        return novels

    def novelIndex(self,novels):
        for nov in  novels:
            url=self.baseUrl+nov[2]
            response = self.session.get(url)
            html = BeautifulSoup(response.text)
            


    #页面文本处理
    def getText(self,bs):
        text=bs.get_text()
        text=text.strip()
        text=text.replace("[","").replace("]","")
        return text

    def getAllLinks(self,url):
        r=self.session.get(url)
        print(r.html.links)
        #按照地址长度归类
        #ddkhtml为章节地址，ddk_为书籍分类，ddk为小说地址
        # sh={"ddk":[],"ddkhtml":[],"ddk_":[],"other":[]}
        # for link in r.html.links:
        #     if "ddk_"  in link:
        #         sh["ddk_"].append(link)
        #     elif ".html" in link and "ddk" in link:
        #         sh["ddkhtml"].append(link)
        #     elif "ddk" in link :
        #         sh["ddk"].append(link)
        #     else:
        #         sh["other"].append(link)

        sh={"biquge":[],"biqugehtml":[],"biquge_":[],"other":[]}
        for link in r.html.links:
            if "biquge_"  in link:
                sh["biquge_"].append(link)
            elif ".html" in link and "biquge" in link:
                sh["biqugehtml"].append(link)
            elif "biquge" in link :
                sh["biquge"].append(link)
            else:
                sh["other"].append(link)


        for name,p in sh.items():
            print(name,p)

#直接写死方法和对应的语句
class sqlDeal(object):
    def __init__(self):
        # self.config  = {'host': '127.0.0.1', 'user': 'root', 'password': 'qwer1234', 'db': 'novel', 'port': 3306, 'charset': 'utf8mb4', 'cursorclass':pymysql.cursors.DictCursor}
        self.config  = {'host': '127.0.0.1', 'user': 'root', 'password': 'qwer1234', 'db': 'novel', 'port': 3306, 'charset': 'utf8mb4'}
        self.limit_count=3 #最低预启动数据库连接数量
        self.pool=PooledDB(pymysql,self.limit_count,use_unicode = True,**self.config)


    #装饰器，用于sql方法执行前后的数据库链接和关闭
    def startAndEnd(func):
        def wrapper(self,argv):
            self.conectSql()
            end=func(self,argv)
            self.closeSql()
            return end
        return wrapper

    #简单sql执行方法
    def smallFactory(self,sqlLine):
        #获取连接池的一个连接，创建游标
        conn=self.pool.connection()
        cursor=conn.cursor()
        #执行sql语句，非select语句，进行一次提交
        try:
            cursor.execute(sqlLine)
            results = cursor.fetchall()
            if "select" not in sqlLine.lower():
                cursor.execute("commit;")
        except Exception as e:
            print(e)
            return
        finally:
            #关闭游标，释放连接到连接池
            cursor.close()
            conn.close()
        return results

    #基础的筛选
    def selectNormal(self,key,sheet,values=" 1=1"):
        text=f"SELECT {key} FROM {sheet} where {values};"
        logging.debug(text)
        return text

    def updateNormal(self,sheet,values,items):
        text = f"UPDATE {sheet} SET {values} where {items};"
        logging.debug(text)
        return text

    #插入sql，mysql使用ignore会返回warning信息，调用warning模块屏蔽
    def insertIgnore(self,key,sheet,values):
        example="INSERT IGNORE INTO books (iplog) VALUES ('MySQL Manual')"
        warnings.filterwarnings("ignore")
        text=f"INSERT IGNORE INTO `{sheet}` ({key}) VALUES ({values});"
        return text

    #存入时，验证是否在表内存在，不存在则存入
    def saveIpList(self,iplist):
        useTable="iplog"
        # 获取初始ip总数，
        logging.info(f"初始ip总数{iplist}")
        selectSql = self.selectNormal("*", useTable)
        logging.debug(selectSql)
        startNum = self.smallFactory(selectSql)
        key=("`ipadress`,`port`,`STATUS`,createtime,updatetime,webcheck")
        for line in iplist:
            logging.info(f"遍历对象{line}")
            ip,port,status=line["ipAdress"],line["port"],line["status"]
            values = (f"'{ip}',{port},{status},NOW(),NOW(),0")
            #此方法存在隐患，会使ip数值急剧增加
            sql=self.insertIgnore(key,useTable,values)
            logging.info(sql)
            self.smallFactory(sql)
        endNum = self.smallFactory(selectSql)
        #总数的变化，可用可不可用的ip都被存入了数据库
        Num=len(endNum) - len(startNum)
        logging.warning(f"*****本次成功新增ip共{Num}条*****")
        return Num

    #获取所有状态为1的ip
    def getIpList(self,argv=None):
        useTable="iplog"
        sql1=self.selectNormal("id,ipadress,port",useTable," status=1 and webcheck<>1  limit 5")
        logging.debug(f"获取可用ip的sql\n{sql1}")
        results=self.smallFactory(sql1)
        return results

    #更新ip状态
    def updateIpStatus(self,useTable,status,id):
        sql1 = self.updateNormal(useTable,f"status={status},updatetime=now(),webcheck=1",f" id={id}")
        logging.debug(f"执行\n{sql1}\n更改状态")
        logging.info("将id {}状态改为 {}".format(id,status))
        results = self.smallFactory(sql1)
        return results

    #批量修改ip状态
    def updateIpListStatus(self,ipLine):
        useTable = "iplog"
        for line in ipLine:
            id,status=line[0],line[1]
            self.updateIpStatus(useTable,status,id)
        return True


    #简单sql的执行方法
    def small(self,sql):
        self.cursor.execute(sql)
        if "select" not in sql and "SELECT" not in sql:
            self.cursor.execute("commit;")
        results = self.cursor.fetchall()
        logging.info(results)
        logging.info("顺利执行完成")
        return results

    #存放可能用到的语句
    def waite(self):
        datetime.datetime(2020, 10, 30, 16, 23, 37).strftime('%Y-%m-%d %H:%M:%S')

    # #搜索ip是否存在
    # @startAndEnd
    # def duplicationIP(self,argv):
    #     useTable="iplog"
    #     sql1=self.selectNormal("ipadress,STATUS",useTable,"where ipadress =\'{}\' and STATUS = 1".format(argv))
    #     results=self.small(sql1)
    #     logging.debug(results)
    #     return results

    #搜索ip是否存在
    def duplicationIP(self,argv,status=None):
        useTable="iplog"
        if status:
            sqlLine = self.selectNormal("ipadress,STATUS", useTable, " ipadress =\'{}\' and status = \'{}\'".format(argv,status))
        else:
            sqlLine=self.selectNormal("ipadress,STATUS",useTable," ipadress =\'{}\'".format(argv))
        results=self.smallFactory(sqlLine)
        logging.debug(results)
        return results


    #链接数据库，获取游标
    def conectSql(self,):
        # 打开数据库连接
        self.db = pymysql.connect(**self.config)
        # 使用cursor()方法获取操作游标
        self.cursor  = self.db.cursor()
        return

    #断开数据库
    def closeSql(self):
        # self.cursor.close()
        self.db.close()
        return

class reqProxies(object):
    def __init__(self):
        self.urltest="http://icanhazip.com/"
        # self.urltest="https://www.biquge98.net/"
        self.headers={
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate', 'Accept-Language': 'zh-CN,zh;q=0.9', 'Cache-Control': 'max-age=0',
            'Connection': 'close', 'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'}
        #创建连接池
        self.sqlCursor=sqlDeal()

    def baseReq(self):
        ipList=self.sqlCursor.getIpList()
        print(ipList)
        print(f"迭代对象{ipList}")
        # if ipList==None :return False
        ipCheckS=[]
        for ip in list(ipList):
            time.sleep(random.randint(2,10))
            iport=ip[1]+":"+str(ip[2])
            proxies={"http":iport,"https":iport}
            logging.info(proxies)
            try:
                end= requests.get(url=self.urltest,proxies=proxies,headers= self.headers,verify=False,timeout=3)
                # if end.text==ip[0]:
                print(f"**\n{end.text}**")
                if end.status_code != 200:
                    continue
                print(type(end.text))
                ipCheckS.append((ip[0],1),)
            except requests.exceptions.ProxyError as e:
                #代理不可用
                ipCheckS.append((ip[0],0), )
            except requests.exceptions.ConnectTimeout as e:
                #链接代理超时
                ipCheckS.append((ip[0],0), )
            except requests.exceptions.ReadTimeout as e:
                #链接、读取超时
                ipCheckS.append((ip[0],0), )
            except requests.exceptions.ConnectionError as e:
                #未知服务器
                ipCheckS.append((ip[0],0), )
            except Exception as e:
                #限定内的其他异常
                ipCheckS.append((ip[0],0), )
                print(e)
            finally:
                print(ipCheckS)
        self.sqlCursor.updateIpListStatus(ipCheckS)
        return ipCheckS

class mocks():
    def test1(self):
        """
        #目的性爬取
        :return:
        """
        url1='https://www.dingdiann.com'
        url2="https://www.dingdiann.com/ddk_1/"
        url3="https://www.dingdiann.com/ddk3380/"
        url4="https://www.biquge98.com/"
        url4="https://www.biquge98.com/"
        fool = getBooknameFromSourse()
        fool.getToSearch(url1)

    def test3Ip(self):
        fool=getIpAndCheck()
        # iplist = fool.getAndlxml("https://www.kuaidaili.com/free/intr/",fool.funcA)
        # iplist=['121.69.10.62:9090', '183.247.152.98:53281', '223.82.106.253:3128','123.139.56.238:9999']
        # ss= fool.checkIp(iplist)
        # validIp=[{'ipAdress': '39.109.123.188', 'port': '3128', 'status': 1}, {'ipAdress': '222.94.196.241', 'port': '3128', 'status': 1}, {'ipAdress': '113.204.164.194', 'port': '8080', 'status': 1}, {'ipAdress': '222.94.196.138', 'port': '3128', 'status': 1}, {'ipAdress': '222.90.110.194', 'port': '8080', 'status': 1}, {'ipAdress': '190.122.186.222', 'port': '8080', 'status': 1}, {'ipAdress': '47.91.137.211', 'port': '3128', 'status': 1}, {'ipAdress': '183.196.170.247', 'port': '9000', 'status': 1}, {'ipAdress': '117.141.155.242', 'port': '53281', 'status': 1}]
        # fool.sqlAndSave(validIp)

        #废物代理网站
        # fool.getAndlxml("https://www.kuaidaili.com/free/inha/",fool.funcA)
        # fool.getAndlxml("https://www.kuaidaili.com/free/intr/",fool.funcA)
        #代理网站checkerproxy，大量ip，慢慢验证
        fool.getAndlxml("https://checkerproxy.net/api/archive/",fool.funcC)
        # fool.getAndlxml("http://www.goubanjia.com/",fool.funcB)
        # fool.getAndlxml("https://www.zdaye.com/",fool.funcC)


    def test4Sql(self):
        fool=sqlDeal()
        # fool.conectSql()
        # fool.selectNormal("*","iplog","")
        # print(fool.insertIgnore())

        # validIp = ['123.139.56.238:9999', '210.61.240.162:8080', '203.189.89.153:8080', '27.191.234.69:9999',
        #            '210.61.240.162:8080', '103.249.100.152:80', '121.89.194.145:3128', '117.141.155.244:53281',
        #            '222.249.238.138:8080', '101.36.160.87:3128', '118.163.13.200:8080', '124.205.155.158:9090',
        #            '47.56.9.58:3128']
        # fool.saveIp(validIp)
        # end=fool.duplicationIP("123.139.56.268")
        statusList=[(254, 0), (255, 0), (257, 0), (261, 0), (263, 0), (265, 0), (266, 0)]
        fool.updateIpListStatus(statusList)

    def test5Req(self):
        fool=reqProxies()
        fool.baseReq()

    def testMain(self):
        IPs=getIpAndCheck()





if __name__=="__main__":
    mock=mocks()
    mock.test1()